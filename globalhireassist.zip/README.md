# Global Hire Assist

**Your Trusted Visa Partner**  
Helping applicants connect to legitimate opportunities across the U.S. — from Mesa, Arizona.

### Features
- About Us section
- Visa & Program listings
- Direct application form (JotForm integration)
- Blog link
- Contact (Email + WhatsApp)
- Privacy & Terms links

### Deployment
1. Fork or clone the repo.
2. Commit & push to GitHub.
3. Enable GitHub Pages in your repo settings.
4. Visit your live website at:
   `https://<your-username>.github.io/globalhireassist/`
